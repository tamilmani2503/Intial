import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-receipes',
  templateUrl: './receipes.component.html',
  styleUrls: ['./receipes.component.css']
})
export class ReceipesComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}
