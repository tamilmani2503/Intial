import { Component, OnInit } from '@angular/core';
import {Receipe} from '../receipe.model';

@Component({
  selector: 'app-receipe-list',
  templateUrl: './receipe-list.component.html',
  styleUrls: ['./receipe-list.component.css']
})
export class ReceipeListComponent implements OnInit {

  
  receipes: Receipe[] =[
    new Receipe('Pizza','This is Pizza','https://get.pxhere.com/photo/dish-pizza-food-cuisine-california-style-pizza-ingredient-pizza-cheese-sicilian-pizza-italian-food-produce-flatbread-recipe-fast-food-comfort-food-vegetarian-food-meat-american-food-pepperoni-cookware-and-bakeware-pizza-stone-tarte-flamb-e-side-dish-junk-food-Take-out-food-supper-brunch-1505771.jpg'),
    new Receipe('Cake', 'This is cake','https://c.pxhere.com/photos/bd/5f/cake_delicious_dessert_food_indulgence_pastry_slice_sweets-1530301.jpg!d')
  ];
  constructor() { }

  ngOnInit(): void {
  }

}
