import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-receipe-item',
  templateUrl: './receipe-item.component.html',
  styleUrls: ['./receipe-item.component.css']
})
export class ReceipeItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
